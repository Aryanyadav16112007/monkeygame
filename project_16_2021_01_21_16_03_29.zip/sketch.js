
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score;
var survivalTime=0;

function preload(){
  
  
  monkey_running =            loadAnimation("monkey_0.png","monkey_1.png","monkey_2.png","monkey_3.png","monkey_4.png","monkey_5.png","monkey_6.png","monkey_7.png","monkey_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  
monkey=createSprite(80,315,20,20);
monkey.addAnimation("moving",monkey_running);
monkey.scale=0.1;
  
ground=createSprite(400,350,900,10);
ground.velocityX=-4;
ground.x=ground.width/2;
console.log(ground.x);
  
obstacleGroup=createGroup();
bananaGroup=createGroup();
  
  score=0;
  
}


function draw() {
background("green");
  
if(ground.x<0){
  ground.x=ground.width/2
}
  spawnObstacles();
  spawnBanana();
  
  if(keyDown("space")&&monkey.y>=300){
    monkey.velocityY=-12;
  }
   if(bananaGroup.isTouching(monkey)){
     bananaGroup.destroyEach();
     score=score+1;
     
    
     
   }
   monkey.velocityY=monkey.velocityY+0.8;
     
     monkey.collide(ground);
     
  drawSprites()
  fill("white");
  text("score:" + score,500,50)
  
  
  fill("black");
  textSize(20);
  survivalTime=Math.ceil(frameCount/frameRate());
  text("survival Time"+survivalTime,100,50)
}
 function spawnObstacles(){
   if(frameCount%150===0){
    var obstacle=createSprite(500,530,20,20);
    obstacle.addImage(obstacleImage);
     obstacle.velocityX=-6;
     
     var rand=Math.round(random(1))
     switch(rand){
       case 1:obstacle.addImage(obstacleImage);
         break;
         default:break;
         
         
     }
     
   obstacle.scale=0.25;
   obstacle.lifetime=500;
   
   obstacleGroup.add(obstacle);
    
   }
  
  function spawnBanana(){
  if(frameCount%160===0){
    banana=createSprite(600,100,40,10);
    banana.y=Math.round(random(250,300));
    banana.addImage(bananaImage);
    banana.scale=0.2;
    banana.velocityX=-3;
    
    monkey.lifetime=500;
    
    banana.depth=monkey.depth;
    monkey.depth=banana.depth+1;
    bananaGroup.add(banana);
  }
    
  }
   
 }





